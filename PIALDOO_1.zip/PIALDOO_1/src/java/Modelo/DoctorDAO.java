/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author jdani
 */
public class DoctorDAO {
      Connection conexion;

    public void abrirConexion() throws SQLException {
        String dbURI = "jdbc:derby://localhost:1527/doctor";
        String username = "fcfm";
        String password = "1234";

        conexion = DriverManager.getConnection(dbURI, username, password);

    }

    public void cerrarConexion() throws SQLException {
        conexion.close();
    }

    public void insertar(Modelo.DoctorPOJO a) {
        try {
            abrirConexion();
            String sql = "insert into DOCTOR values ('" + a.getNombre() + "', '" + a.getEdad() + "' )" + a.getMuertos() + "' )" + a.getNacionalidad() + "' )" + a.getId() + "' )" + a.getNumero() + "' )" + a.getReconocimientos() + "' )";
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate(sql);
            cerrarConexion();
        } catch (SQLException e) {
            System.out.println("ERROR: " + e);
        }

    }

    public List buscar(modelo.ComentariosPOJO a) {
        ResultSet mensajes;
        List beans = new ArrayList();
        try {
            abrirConexion();
            String sql;
            sql= "SELECT * from DOCTOr WHERE NOMBRE = '"+ a.getNombre() +"'";
            Statement stmt = conexion.createStatement();
            mensajes = stmt.executeQuery(sql);
            while (mensajes.next()) {
                String nombre = mensajes.getString("NOMBRE");
                String edad = mensajes.getString("EDAD");
                String muertos = mensajes.getString("MUERTOS");
                String nacionalidad = mensajes.getString("NACIONALIDAD");
                String id = mensajes.getString("ID");
                String numero = mensajes.getString("NUMERO");
                String reconocimeinto = mensajes.getString("RECONOCIMIENTO");
                
                Modelo.DoctorPOJO ComentarioBean = new Modelo.DoctorPOJO(nombre, edad, muertos, nacionalidad, id, numero, reconocimeinto);
                beans.add(ComentarioBean);
            }
            cerrarConexion();
        } catch (SQLException e) {
            System.out.println("ERROR: " + e);
        }
        return beans;
    }
    
    public void borrar(modelo.ComentariosPOJO a){
         try {
            abrirConexion();
            String sql = "DELETE FROM DOCTOR WHERE NOMBRE = '"+ a.getNombre() +"'";
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate(sql);
            cerrarConexion();
        } catch (SQLException e) {
            System.out.println("ERROR: " + e);
        }
        
        
            }
    
}
