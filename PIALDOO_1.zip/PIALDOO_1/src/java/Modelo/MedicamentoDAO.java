/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author jdani
 */
public class MedicamentoDAO {
    Connection conexion;

    public void abrirConexion() throws SQLException {
        String dbURI = "jdbc:derby://localhost:1527/medicamentos";
        String username = "fcfm";
        String password = "1234";

        conexion = DriverManager.getConnection(dbURI, username, password);

    }

    public void cerrarConexion() throws SQLException {
        conexion.close();
    }
    
        public void insertar(MedicamentoPOJO a) {
        try {
            abrirConexion();
            String sql = "insert into MEDICAMENTO values ('" + a.getMedicamento() + "', '" + a.getFolio() + "')" + a.getCaducidad() + "')" + a.getCosto() + "')" + a.getGramos() + "')" ;
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate(sql);
            cerrarConexion();
        } catch (SQLException e) {
            System.out.println("ERROR: " + e);
        }
        }
        
         public List buscar(MedicamentoPOJO a) {
        ResultSet mensajes;
        List beans = new ArrayList();
        try {
            abrirConexion();
            String sql;
            sql= "SELECT * from Medicamento WHERE MEDICAMENTO = '"+ a.getMedicamento() +"'";
            Statement stmt = conexion.createStatement();
            mensajes = stmt.executeQuery(sql);
            while (mensajes.next()) {
                String medicamento = mensajes.getString("MEDICAMENTO");
                String folio = mensajes.getString("FOLIO");
                  String caducidad = mensajes.getString("CADUCIDAD");
                    String costo = mensajes.getString("COSTO");
                      String gramos = mensajes.getString("GRAMOS");
                      
                MedicamentoPOJO ComentarioBean = new MedicamentoPOJO(medicamento, folio,caducidad,costo,gramos);
                beans.add(ComentarioBean);
            }
            cerrarConexion();
        } catch (SQLException e) {
            System.out.println("ERROR: " + e);
        }
        return beans;
    }
}

