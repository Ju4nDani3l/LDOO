/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author jdani
 */
public class Persona {
String nombre;
 int edad;
 String apeluno;
 String apeldos;
 String fecha;
 String correo;
 String passw;

    public Persona(String nombre, int edad, String apeluno, String apeldos, String fecha, String correo, String passw) {
        this.nombre = nombre;
        this.edad = edad;
        this.apeluno = apeluno;
        this.apeldos = apeldos;
        this.fecha = fecha;
        this.correo = correo;
        this.passw = passw;
    }

   

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getApeluno() {
        return apeluno;
    }

    public void setApeluno(String apeluno) {
        this.apeluno = apeluno;
    }

    public String getApeldos() {
        return apeldos;
    }

    public void setApeldos(String apeldos) {
        this.apeldos = apeldos;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getPassw() {
        return passw;
    }

    public void setPassw(String passw) {
        this.passw = passw;
    }

   
    }

  

    

   
    

    

   


