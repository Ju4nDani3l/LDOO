/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author jdani
 */
public class MedicamentoPOJO {

    public String medicamento;
    public String folio;
    public String caducidad;
    public String costo;
    public String gramos;

    public String getMedicamento() {
        return medicamento;
    }

    public void setMedicamento(String medicamento) {
        this.medicamento = medicamento;
    }

    public String getFolio() {
        return folio;
    }

    public void setFolio(String folio) {
        this.folio = folio;
    }

    public String getCaducidad() {
        return caducidad;
    }

    public void setCaducidad(String caducidad) {
        this.caducidad = caducidad;
    }

    public String getCosto() {
        return costo;
    }

    public void setCosto(String costo) {
        this.costo = costo;
    }

    public String getGramos() {
        return gramos;
    }

    public void setGramos(String gramos) {
        this.gramos = gramos;
    }

        public MedicamentoPOJO(String medicamento, String folio, String caducidad, String costo, String gramos) {
        this.medicamento = medicamento;
        this.folio = folio;
        this.caducidad = caducidad;
        this.costo=costo;
        this.gramos=gramos;
    }
 
}

   

