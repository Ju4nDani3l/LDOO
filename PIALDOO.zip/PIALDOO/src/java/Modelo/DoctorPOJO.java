/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author jdani
 */
public class DoctorPOJO {
public String nombre;
public String edad;
public String muertos;
public String nacionalidad;
public String id;
public String numero;
public String reconocimientos;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public String getMuertos() {
        return muertos;
    }

    public void setMuertos(String muertos) {
        this.muertos = muertos;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getReconocimientos() {
        return reconocimientos;
    }

    public void setReconocimientos(String reconocimientos) {
        this.reconocimientos = reconocimientos;
    }

 public DoctorPOJO(String nombre, String edad , String muertos, String nacionalidad, String id, String numero, String reconocimientos) {
        this.nombre = nombre;
        this.edad = edad;
        this.muertos=muertos;
        this.nacionalidad=nacionalidad;
        this.id=id;
        this.numero=numero;
        this.reconocimientos=reconocimientos;
        
    }

    







    
}
