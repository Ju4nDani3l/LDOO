/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author 
 */
public class ComentariosDAO {

    Connection conexion;

    public void abrirConexion() throws SQLException {
        String dbURI = "jdbc:derby://localhost:1527/Comentarios2";
        String username = "fcfm";
        String password = "lsti01";

        conexion = DriverManager.getConnection(dbURI, username, password);

    }

    public void cerrarConexion() throws SQLException {
        conexion.close();
    }

    public void insertar(ComentariosPOJO a) {
        try {
            abrirConexion();
            String sql = "insert into COMENTARIO values ('" + a.getNombre() + "', '" + a.getComentario() + "')";
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate(sql);
            cerrarConexion();
        } catch (SQLException e) {
            System.out.println("ERROR: " + e);
        }

    }

    public List buscar(ComentariosPOJO a) {
        ResultSet mensajes;
        List beans = new ArrayList();
        try {
            abrirConexion();
            String sql;
            sql= "SELECT * from COMENTARIO WHERE NOMBRE = '"+ a.getNombre() +"'";
            Statement stmt = conexion.createStatement();
            mensajes = stmt.executeQuery(sql);
            while (mensajes.next()) {
                String nombre = mensajes.getString("NOMBRE");
                String comentario = mensajes.getString("COMENTARIO");
                ComentariosPOJO ComentarioBean = new ComentariosPOJO(nombre, comentario);
                beans.add(ComentarioBean);
            }
            cerrarConexion();
        } catch (SQLException e) {
            System.out.println("ERROR: " + e);
        }
        return beans;
    }
    
    public void borrar(ComentariosPOJO a){
         try {
            abrirConexion();
            String sql = "DELETE FROM COMENTARIO WHERE NOMBRE = '"+ a.getNombre() +"'";
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate(sql);
            cerrarConexion();
        } catch (SQLException e) {
            System.out.println("ERROR: " + e);
        }
        
        
            }


}
